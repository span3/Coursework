#include <lib.h>
#include <unistd.h>

PUBLIC int set_key (unsigned int k0, unsigned int k1);